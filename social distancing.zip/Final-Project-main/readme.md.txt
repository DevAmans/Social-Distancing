Steps to run the program:

Step 1: Install Anaconda IDE (https://docs.anaconda.com/anaconda/install/windows/)

Step 2: Open PyCharm in Anaconda

Step 3: Install opencv library

Step 4: Open the source code file and place the video in the correct folder

Step 5: Run the file

Step 6: Video should appear detecting humans and monitoring social distancing after running the code

Step 7: Press Esc key to close the video window